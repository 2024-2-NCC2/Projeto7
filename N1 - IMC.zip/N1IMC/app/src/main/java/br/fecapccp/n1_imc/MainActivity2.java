package br.fecapccp.n1_imc;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.DecimalFormat;

import br.fecapccp.n1_imc.R;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void calcularImc(View view){
        EditText campoAltura = findViewById(R.id.editTextAltura);
        EditText campoPeso = findViewById(R.id.editTextPeso);
        TextView resultado = findViewById(R.id.textResultado);

        String altura = campoAltura.getText().toString();
        String peso = campoAltura.getText().toString();

        Double numAltura = Double.parseDouble(altura);
        Double numPeso = Double.parseDouble(peso);
        Double numImc = numPeso / (numAltura * numAltura);

        String imc = String.valueOf(numImc);

        DecimalFormat df = new DecimalFormat("##.##");
        imc = df.format(numImc);

        resultado.setText((imc + "kg/m2"));

    }

    public void limpar(View view){
        EditText campoAltura = findViewById(R.id.editTextAltura);
        EditText campoPeso = findViewById(R.id.editTextPeso);
        TextView resultado = findViewById(R.id.textResultado);

        resultado.setText("-----");
        campoPeso.setText("");
        campoAltura.setText("");
    }

}






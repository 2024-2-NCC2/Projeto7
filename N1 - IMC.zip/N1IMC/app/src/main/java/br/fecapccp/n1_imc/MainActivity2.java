package br.fecapccp.n1_imc;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.DecimalFormat;

public class MainActivity2 extends AppCompatActivity {

    Button btnReset2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        btnReset2 = findViewById(R.id.btnReset2);

        btnReset2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Voltar para a MainActivity
                Intent intent = new Intent(MainActivity2.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        }); // ✅ Fechando o setOnClickListener corretamente
    }

    public void calcularImc(View view) {
        EditText campoAltura = findViewById(R.id.editTextAltura);
        EditText campoPeso = findViewById(R.id.editTextPeso);
        TextView resultado = findViewById(R.id.textResultado);

        String altura = campoAltura.getText().toString();
        String peso = campoPeso.getText().toString(); // ❗ Aqui você estava pegando o valor errado

        Double numAltura = Double.parseDouble(altura);
        Double numPeso = Double.parseDouble(peso);
        Double numImc = numPeso / (numAltura * numAltura);

        DecimalFormat df = new DecimalFormat("##.##");
        String imc = df.format(numImc);

        resultado.setText(imc + " kg/m²");
    }

    public void limpar(View view) {
        EditText campoAltura = findViewById(R.id.editTextAltura);
        EditText campoPeso = findViewById(R.id.editTextPeso);
        TextView resultado = findViewById(R.id.textResultado);

        resultado.setText("-----");
        campoPeso.setText("");
        campoAltura.setText("");
    }
}
